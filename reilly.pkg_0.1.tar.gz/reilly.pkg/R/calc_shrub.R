calc_shrub_vol <- function(height, length, width) {
volume <- height * length * width
return(volume)
}

