FunFunction <- function(number){
     if(is.numeric(number) == TRUE){
         print("THIS IS INDEED A NUMBER")
     }
     if(is.numeric(number) == FALSE){
         print("THIS IS NOT A NUMBER. TRY AGAIN.")
     }
}

