# reilly.pkg
## An R package for processing data sets

 An R package used to perform numerous functions on a data set. 
Cleaning data, plotting data, and running models on your data is all possible using this package.
